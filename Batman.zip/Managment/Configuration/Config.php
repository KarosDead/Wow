<?php
date_default_timezone_set('europe/madrid');
	define('DB_HOST', 'IP');
	define('DB_NAME', 'DBName');
	define('DB_USERNAME', 'DBUser');
	define('DB_PASSWORD', 'DBPASSWORD');
	define('ERROR_MESSAGE', '<style>
body 
{
	background-color: black;
	color:white;
}
.alert-danger
{
	color:red;
}
.alert-success
{
	color:lime;
}
</style><span style="color: red;">Error db Please Wait!');